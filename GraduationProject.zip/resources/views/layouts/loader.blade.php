{{-- 

    <div class="sk-chase">
        <div class="sk-chase-dot"></div>
        <div class="sk-chase-dot"></div>
        <div class="sk-chase-dot"></div>
        <div class="sk-chase-dot"></div>
        <div class="sk-chase-dot"></div>
        <div class="sk-chase-dot"></div>
      </div>
</div> --}}

<div class="loader-container">
    <div class="spinner">
        <div class="dot1"></div>
        <div class="dot2"></div>
    </div>
    {{-- <div class="loader"></div> --}}
   
  </div>