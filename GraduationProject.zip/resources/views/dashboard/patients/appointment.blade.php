<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded w-100" id="appointment-table">
                <thead class="thead-light">
                    <tr>
                        
                        <th class="border-0 rounded-start">Date</th>
                        <th class="border-0 ">Time From and To</th>
                        <th class="border-0 ">Category</th>
                        <th class="border-0">Currency</th>
                        <th class="border-0">Amount</th>                       
                        <th class="border-0">Payment Status</th>
                        <th class="border-0">Payment Date</th>

                    </tr>
                </thead>
                <tbody>
                    
                </tbody>
            </table>
        </div>
    </div>
    
</div>