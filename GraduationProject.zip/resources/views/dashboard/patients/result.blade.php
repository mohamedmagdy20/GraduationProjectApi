<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded" id="result-table">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">img</th>
                        <th class="border-0 ">Doctor Name</th>
                        <th class="border-0">Category</th>
                        <th class="border-0">Result</th>                       
                        <th class="border-0">Rate</th>           
                    </tr>
                </thead>
                <tbody>
                    
                </tbody>
            </table>
        </div>
    </div>
    
</div>